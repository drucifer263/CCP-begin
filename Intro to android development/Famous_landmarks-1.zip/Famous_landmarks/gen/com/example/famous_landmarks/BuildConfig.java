/** Automatically generated file. DO NOT MODIFY */
package com.example.famous_landmarks;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}