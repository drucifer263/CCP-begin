package com.example.tipcalculator;

import android.app.Activity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.view.Menu;
import android.view.MenuItem;

import java.text.DecimalFormat;
import java.text.NumberFormat;

public class MainActivity extends Activity 
{
	private static final NumberFormat currencyFormat = NumberFormat.getCurrencyInstance();
	private static final NumberFormat percentFormat = NumberFormat.getPercentInstance();
	
	private double billAmount = 0.0;
	private double customPercent = 0.18;
	private double customPeople = 0.01;
	private double taxPercent = 0.07;
	//private double billAmountTax = 0.0;
	private TextView amountDisplayTextView;
	private TextView percentCustomTextView;
	private TextView tip15TextView;
	private TextView total15TextView;
	private TextView tipCustomTextView;
	private TextView totalCustomTextView;
	
	private TextView peopleTextView;
	private TextView totalTax15TextView;
	private TextView totalTaxCustomTextView;

	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		amountDisplayTextView = (TextView)findViewById(R.id.amountDisplayTextView);
		percentCustomTextView =(TextView)findViewById(R.id.percentCustomTextView);
		tip15TextView = (TextView)findViewById(R.id.tip15TextView);
		total15TextView = (TextView)findViewById(R.id.total15TextView);
		tipCustomTextView = (TextView)findViewById(R.id.tipCustomTextView);
		totalCustomTextView = (TextView)findViewById(R.id.totalCustomTextView);
		totalTax15TextView = (TextView)findViewById(R.id.totalTax15TextView);
		totalTaxCustomTextView = (TextView)findViewById(R.id.totalTaxCustomTextView);
		
		peopleTextView =(TextView)findViewById(R.id.peopleTextView);
		amountDisplayTextView.setText(currencyFormat.format(billAmount));
		
		
		updateStandardWithPeople();
		updateCustomWithPeople();
		updateStandardWithPeopleAndTax();
		updateCustomWithPeopleAndTax();
		//updateStandard();
		//updateCustom();
		
		
		EditText amountEditText = (EditText)findViewById(R.id.amountEditText);
		amountEditText.addTextChangedListener(amountEditTextWatcher);
		
		SeekBar customTipSeekBar = (SeekBar)findViewById(R.id.customTipSeekBar);
		customTipSeekBar.setOnSeekBarChangeListener(customSeekBarListener);
		
		SeekBar customPeopleSeekBar = (SeekBar)findViewById(R.id.customPeopleSeekBar);
		customPeopleSeekBar.setOnSeekBarChangeListener(customPeopleSeekBarListener);
		
	}

	/*private void updateStandard()
	{
		double fifteenPercentTip = 0.0;
		double fifteenPercentTotal = 0.0;
		
		
		fifteenPercentTip = billAmount * 0.15;
		fifteenPercentTotal = billAmount + fifteenPercentTip;
		
		tip15TextView.setText(currencyFormat.format(fifteenPercentTip));
		total15TextView.setText(currencyFormat.format(fifteenPercentTotal));
	}
	
	private void updateCustom()
	{
		double customTip = 0.0;
		double customTotal = 0.0;
		//double customTaxTotal = 0.0;
		//int customPeople = 0;
		
		percentCustomTextView.setText(percentFormat.format(customPercent));
		
		customTip = billAmount * customPercent;
		customTotal = billAmount + customTip;
		
		tipCustomTextView.setText(currencyFormat.format(customTip));
		totalCustomTextView.setText(currencyFormat.format(customTotal));
	}
	*/
	
	private void updateStandardWithPeople()
	{
		
		double fifteenPercentTipWithPeople = 0.0;
		double fifteenPercentTotalWithPeople = 0.0;
		
		peopleTextView.setText(percentFormat.format(customPeople));
		//customPeople = customPeople * 100.0;
		
		fifteenPercentTipWithPeople = (billAmount * 0.15) / customPeople;
		fifteenPercentTotalWithPeople = (billAmount + (fifteenPercentTipWithPeople * customPeople) )/ customPeople ;
		
		
		tip15TextView.setText(currencyFormat.format(fifteenPercentTipWithPeople));
		total15TextView.setText(currencyFormat.format(fifteenPercentTotalWithPeople));
		
	}
	
	private void updateStandardWithPeopleAndTax()
	{
		
		double fifteenPercentTipWithPeopleTax = 0.0;
		double fifteenPercentTotalWithPeopleTax = 0.0;
		double billAmountTax = 0.0;
		double billAmountWithTax = 0.0;
		
		
		peopleTextView.setText(percentFormat.format(customPeople));
		//customPeople = customPeople * 100.0;
		
		billAmountTax = billAmount * taxPercent;
		billAmountWithTax = billAmount + billAmountTax;
		
		fifteenPercentTipWithPeopleTax = (billAmountWithTax * 0.15) / customPeople;
		
		fifteenPercentTotalWithPeopleTax = (billAmountWithTax + (fifteenPercentTipWithPeopleTax * customPeople)) /customPeople ;
		
		totalTax15TextView.setText(currencyFormat.format(fifteenPercentTotalWithPeopleTax));
		
		
	}
	
	private void updateCustomWithPeople()
	{
		double customTipWithPeople = 0.0;
		double customTotalWithPeople = 0.0;
		
		peopleTextView.setText(percentFormat.format(customPeople));
		percentCustomTextView.setText(percentFormat.format(customPercent));
		
		//customPeople = customPeople * 100.0;
		
		customTipWithPeople = (billAmount * customPercent) / customPeople;
		customTotalWithPeople = (billAmount + (customTipWithPeople * customPeople))/customPeople;
		
		tipCustomTextView.setText(currencyFormat.format(customTipWithPeople));
		totalCustomTextView.setText(currencyFormat.format(customTotalWithPeople));
	}
	
	private void updateCustomWithPeopleAndTax()
	{
		double customTipWithPeopleTax = 0.0;
		double customTotalWithPeopleTax = 0.0;
		double totalTax = 0.0;
		double totalWithTax = 0.0;
		
		
		peopleTextView.setText(percentFormat.format(customPeople));
		percentCustomTextView.setText(percentFormat.format(customPercent));
		
		//customPeople = customPeople * 100.0;
		
		totalTax = billAmount * taxPercent;
		totalWithTax = billAmount + totalTax;
		
		customTipWithPeopleTax = (totalWithTax * customPercent) / customPeople;
		customTotalWithPeopleTax = (totalWithTax + (customTipWithPeopleTax * customPeople)) / customPeople;
		
		
		totalTaxCustomTextView.setText(currencyFormat.format(customTotalWithPeopleTax));
	}
	private OnSeekBarChangeListener customSeekBarListener = new OnSeekBarChangeListener()
	{
		@Override
		public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser)
		{
			customPercent = progress/100.0;
			//updateCustom();
			updateCustomWithPeople();
			updateCustomWithPeopleAndTax();
		}
		
		@Override
		public void onStartTrackingTouch(SeekBar seekBar)
		{	
		}
		
		@Override
		public void onStopTrackingTouch(SeekBar seekBar)
		{
		}
	};
	
	private OnSeekBarChangeListener customPeopleSeekBarListener = new OnSeekBarChangeListener()
	{
		@Override
		public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser)
		{
			//if(progress == 0)
			//{
			//	progress = progress + 1;
			//}
			
			//try
		//	{
				//if(progress == 0)
			//	{progress = progress + 1;}
				
				customPeople = progress/100.0;
				
			//}
			
			//catch (Exception e)
			//{
				
		//		customPeople = progress + 1;
			//}
			//updateCustom();
			updateStandardWithPeople();
			updateCustomWithPeople();
			updateStandardWithPeopleAndTax();
			updateCustomWithPeopleAndTax();
			
		}
		
		@Override
		public void onStartTrackingTouch(SeekBar seekBar)
		{	
		}
		
		@Override
		public void onStopTrackingTouch(SeekBar seekBar)
		{
		}
	};
	
	private TextWatcher amountEditTextWatcher = new TextWatcher()
	{
		@Override
		public void onTextChanged(CharSequence s, int start, int before, int count)
		{
			try
			{
				billAmount = Double.parseDouble(s.toString()) / 100.0;
			}
			
			catch (NumberFormatException e)
			{
				billAmount = 0.0;
			}
			
			amountDisplayTextView.setText(currencyFormat.format(billAmount));
			
			updateStandardWithPeople();
			updateCustomWithPeople();
			updateStandardWithPeopleAndTax();
			updateCustomWithPeopleAndTax();
			//updateStandard();
			//updateCustom();
		}
		
		@Override
		public void afterTextChanged(Editable s)
		{
		}
		
		@Override
		public void beforeTextChanged(CharSequence s, int start, int count, int after)
		{
		}
	};
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) 
	{
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) 
	{
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) 
		{
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
