/** Automatically generated file. DO NOT MODIFY */
package com.example.tipcalculator;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}