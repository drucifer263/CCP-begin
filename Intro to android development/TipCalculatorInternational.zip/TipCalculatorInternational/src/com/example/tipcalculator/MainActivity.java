/*
 	Drew Watson
 	CSCI 215
 	Spring 15
 	Nelson
 	
 	good version 2.0
 */


package com.example.tipcalculator;

import android.app.Activity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.view.Menu;
import android.view.MenuItem;

import java.io.IOException;
import java.text.NumberFormat;

public class MainActivity extends Activity 
{
	private static final NumberFormat currencyFormat = NumberFormat.getCurrencyInstance();
	private static final NumberFormat percentFormat = NumberFormat.getPercentInstance();
	private static final NumberFormat integerFormat = NumberFormat.getIntegerInstance(); 
	
	private double billAmount = 0.0;
	private double customPercent = 0.18;
	private double amountOfPeople = 1;
	private double taxPercent = 0.07;
	private TextView amountDisplayTextView;
	private TextView percentCustomTextView;
	private TextView tip15TextView;
	private TextView total15TextView;
	private TextView tipCustomTextView;
	private TextView totalCustomTextView;
	
	private TextView peopleAmountDisplayTextView;
	private TextView total15WithTaxTextView;
	private TextView totalCustomWithTaxTextView;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		amountDisplayTextView = (TextView)findViewById(R.id.amountDisplayTextView);
		percentCustomTextView =(TextView)findViewById(R.id.percentCustomTextView);
		tip15TextView = (TextView)findViewById(R.id.tip15TextView);
		total15TextView = (TextView)findViewById(R.id.total15TextView);
		tipCustomTextView = (TextView)findViewById(R.id.tipCustomTextView);
		totalCustomTextView = (TextView)findViewById(R.id.totalCustomTextView);
		
		peopleAmountDisplayTextView = (TextView)findViewById(R.id.peopleAmountDisplayTextView);
		total15WithTaxTextView = (TextView)findViewById(R.id.total15WithTaxTextView);
		totalCustomWithTaxTextView = (TextView)findViewById(R.id.totalCustomWithTaxTextView);
		
		peopleAmountDisplayTextView.setText(integerFormat.format(amountOfPeople));
		amountDisplayTextView.setText(currencyFormat.format(billAmount));
		
		updateStandard();
		updateCustom();
		
		EditText amountEditText = (EditText)findViewById(R.id.amountEditText);
		amountEditText.addTextChangedListener(amountEditTextWatcher);
		
		EditText peopleAmountEditText = (EditText)findViewById(R.id.peopleAmountEditText);
		peopleAmountEditText.addTextChangedListener(peopleAmountEditTextWatcher);
		
		SeekBar customTipSeekBar = (SeekBar)findViewById(R.id.customTipSeekBar);
		customTipSeekBar.setOnSeekBarChangeListener(customSeekBarListener);
		
		
	}

	private void updateStandard()
	{
		double fifteenPercentTip = 0.0;
		double fifteenPercentTotal = 0.0;
		
		fifteenPercentTip = (billAmount * 0.15) / amountOfPeople;
		fifteenPercentTotal = (billAmount + (fifteenPercentTip * amountOfPeople)) / amountOfPeople;
		
		tip15TextView.setText(currencyFormat.format(fifteenPercentTip));
		total15TextView.setText(currencyFormat.format(fifteenPercentTotal));
		updateStandardWithTax();
		
	}
	
	private void updateCustom()
	{
		double customTip = 0.0;
		double customTotal = 0.0;
		
		percentCustomTextView.setText(percentFormat.format(customPercent));
		
		customTip = (billAmount * customPercent) / amountOfPeople;
		customTotal = (billAmount + (customTip * amountOfPeople)) / amountOfPeople;
		
		tipCustomTextView.setText(currencyFormat.format(customTip));
		totalCustomTextView.setText(currencyFormat.format(customTotal));
		updateCustomWithTax();
	}
	
	private void updateStandardWithTax()
	{
		double tax = 0.0;
		double totalWithTax = 0.0;
		double fifteenPercentTipWithTax = 0.0;
		double fifteenPercentWithTaxTotal = 0.0;
		
		tax = billAmount * taxPercent;
		totalWithTax = billAmount + tax;
		
		fifteenPercentTipWithTax = (totalWithTax * 0.15) / amountOfPeople;
		fifteenPercentWithTaxTotal = (totalWithTax + (fifteenPercentTipWithTax * amountOfPeople)) / amountOfPeople;
		
		total15WithTaxTextView.setText(currencyFormat.format(fifteenPercentWithTaxTotal));
	}
	
	private void updateCustomWithTax()
	{
		double customTipWithTax = 0.0;
		double customTotalWithTax = 0.0;
		double tax = 0.0;
		double totalWithTax = 0.0;
		
		percentCustomTextView.setText(percentFormat.format(customPercent));
		
		tax = billAmount * taxPercent;
		totalWithTax = billAmount + tax;
		
		
		customTipWithTax = (totalWithTax * customPercent) / amountOfPeople;
		
		if(customTipWithTax == 0)
		{
		customTotalWithTax = totalWithTax / amountOfPeople;
		totalCustomWithTaxTextView.setText(currencyFormat.format(customTotalWithTax));
		}
		
		else
		{
		customTotalWithTax = (totalWithTax + (customTipWithTax * amountOfPeople)) / amountOfPeople;
		totalCustomWithTaxTextView.setText(currencyFormat.format(customTotalWithTax));
		}
		
		
	}
	
	private OnSeekBarChangeListener customSeekBarListener = new OnSeekBarChangeListener()
	{
		@Override
		public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser)
		{
			customPercent = progress/100.0;
			updateCustom();
		}
		
		@Override
		public void onStartTrackingTouch(SeekBar seekBar)
		{	
		}
		
		@Override
		public void onStopTrackingTouch(SeekBar seekBar)
		{
		}
	};
	
	private TextWatcher amountEditTextWatcher = new TextWatcher()
	{
		@Override
		public void onTextChanged(CharSequence s, int start, int before, int count)
		{
			try
			{
				billAmount = Double.parseDouble(s.toString()) / 100.0;
			}
			
			catch (NumberFormatException e)
			{
				billAmount = 0.0;
			}
			
			amountDisplayTextView.setText(currencyFormat.format(billAmount));
			updateStandard();
			updateCustom();
		}
		
		@Override
		public void afterTextChanged(Editable s)
		{
		}
		
		@Override
		public void beforeTextChanged(CharSequence s, int start, int count, int after)
		{
		}
	};
	
	private TextWatcher peopleAmountEditTextWatcher = new TextWatcher()
	{
		@Override
		public void onTextChanged(CharSequence s, int start, int before, int count)
		{
			
			
			try
			{
				amountOfPeople = Integer.parseInt(s.toString());
				
			}
			
			catch (NumberFormatException e )
			{
				amountOfPeople = 1;
			}
			
			if(amountOfPeople == 0)
			{
				amountOfPeople = amountOfPeople++;
				peopleAmountDisplayTextView.setText(integerFormat.format(amountOfPeople));
				updateStandard();
				updateCustom();
			}
			
			else
			{
				peopleAmountDisplayTextView.setText(integerFormat.format(amountOfPeople));
				updateStandard();
				updateCustom();
			}
		}
		
		@Override
		public void afterTextChanged(Editable s)
		{
			
		}
		
		@Override
		public void beforeTextChanged(CharSequence s, int start, int count, int after)
		{
			
		}
	};
	@Override
	public boolean onCreateOptionsMenu(Menu menu) 
	{
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) 
	{
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) 
		{
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
